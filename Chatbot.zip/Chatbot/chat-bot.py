# create a chatbot using NLTK library in python

import nltk
from nltk.chat.util import Chat,reflections

#Define some chatbot responses
pairs = [
              ['My name is (.*)',['Hi % 1']],
              ['Hi|Hello|Hyy',['Hello!','Hello!....say anything']],
              ['What is your name?',['My name is A Real Chatbot.']],
              ['How are you?',['I am doing well, thank you!']],
              ['What are you doing now?',['Now i am assist you!']],
              ['About your self?',['of-course, I am Real Chatbot whose create by- Mr. David Raut.']],
              ['Who are you?',['I am just a program, I was created by Mr. David Raut.']],
              ['Suggest trending movie?',['Now at the time, Pushpa-2 is the trending movie in theater.']],
              ['ok byy|byy|exit|quit',['Good byy!, Have a greate day!, "See you soon"']]
        ]


class AutoTerminateChat(Chat):
    def converse(self, quit="bye"):
        print("Type 'bye' to exit.\n")
        print("How can I assist you today?\n")
        while True:
            user_input = input("> ")
            if user_input.lower() in [quit, "ok byy", "byy", "exit", "quit"]:
                print("Goodbye! Have a great day! See you soon !")
                break

            response = self.respond(user_input)
            if response:
                print(response)
            else:
                print("I didn't understand that. Can you rephrase?")

# create the chatbot
chatbot = AutoTerminateChat(pairs,reflections)

# Strat Chatting
print("Hello, I am a Real Chatbot. How can I assist you?")
chatbot.converse()